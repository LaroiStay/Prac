
using ServerCore;
class PacketManager
{
    #region SingleTon
    
    static PacketManager m_instance;
    public static PacketManager Instance { get { if (m_instance == null) m_instance = new PacketManager();
            return m_instance; } }
    #endregion
    
    Dictionary<ushort, Action<PacketSession, ArraySegment<byte>>> m_onRecv = new
        Dictionary<ushort, Action<PacketSession, ArraySegment<byte>>>();
    Dictionary<ushort, Action<PacketSession, IPacket>> m_handler = new
        Dictionary<ushort, Action<PacketSession, IPacket>>();
    
    public void Register()
    {
                m_onRecv.Add((ushort)PacketID.PlayerInfoReq, MakePacket<PlayerInfoReq>);
        m_handler.Add((ushort)PacketID.PlayerInfoReq, PacketHandler.PlayerInfoReqHandler);

        m_onRecv.Add((ushort)PacketID.Test, MakePacket<Test>);
        m_handler.Add((ushort)PacketID.Test, PacketHandler.TestHandler);


    }
    
    public void OnRecvPacket(PacketSession session, ArraySegment<byte> buffer)
    {
    
        ushort count = 0;
        ushort size = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
        count += 2;
        ushort id = BitConverter.ToUInt16(buffer.Array, buffer.Offset + count);
        count += 2;
    
    
        Action<PacketSession, ArraySegment<byte>> action = null;
        if (m_onRecv.TryGetValue(id, out action))
            action.Invoke(session, buffer);
    }
    
    void MakePacket<T>(PacketSession session, ArraySegment<byte> buffer )where T: IPacket, new ()
    {
        T p = new T();
        p.Read(buffer);
    
        Action<PacketSession, IPacket> action = null;
        if (m_handler.TryGetValue(p.Protocol, out action))
            action.Invoke(session,p);
    }
}
