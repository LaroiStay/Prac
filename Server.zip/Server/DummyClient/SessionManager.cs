﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DummyClient
{
     class SessionManager
    {
        static SessionManager m_session = new SessionManager();
        public static SessionManager Instance { get { return m_session; } }
        List<ServerSession> m_sessions = new List<ServerSession>();
        object m_lock = new object();
        Random m_rand = new Random();

        public ServerSession Generate()
        {
            lock (m_lock)
            {
                ServerSession serversession = new ServerSession();
                m_sessions.Add(serversession);
                return serversession;
            }
        }

        public void SendForEach()
        {
            lock (m_lock)
            {
                foreach(ServerSession ses in m_sessions)
                {
                    C_Move movepacket = new C_Move();
                    movepacket.posX = m_rand.Next(-50, 50);
                    movepacket.posY = m_rand.Next(-50, 50);
                    movepacket.posZ = m_rand.Next(-50, 50);
                    ArraySegment<byte> segment = movepacket.Write();
                    ses.Send(segment);
                }
            }
        }






    }
}
