﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using ServerCore;

namespace DunmmyClient
{

    class Program
    {

        static void Main(string[] args)
        {
            string host = Dns.GetHostName();
            IPHostEntry IPhost = Dns.GetHostEntry(host);
            IPAddress IPAdr = IPhost.AddressList[0];
            IPEndPoint endPoint = new IPEndPoint(IPAdr, 7777);

            Connecter connecter = new Connecter();
            connecter.Connect(endPoint, () => { return DummyClient.SessionManager.Instance.Generate();},
                10);


            while (true)
            {

                try
                {
                    DummyClient.SessionManager.Instance.SendForEach();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }

                Thread.Sleep(250); 
                
            }
          
          


        }
    }


}